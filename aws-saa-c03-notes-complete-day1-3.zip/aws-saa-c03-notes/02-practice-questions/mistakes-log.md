# Mistakes Log

Every wrong answer becomes a rule. Review this before practice exams.

| Date | Source | Domain | Concept | What I picked / why wrong | The rule to remember |
|------|--------|--------|---------|---------------------------|----------------------|
| | | | | | |

## Traps noticed even when I got it right (Day 3)
| Date | Source | Concept | Trap | Rule |
|------|--------|---------|------|------|
| 2026-10-15 | Domain 1 practice | HTTPS on ALB | Listener encrypts only client to ALB | Check every hop if "all data in transit" |
| 2026-10-15 | Domain 1 practice | AZ vs subnet | Two subnets can share one AZ | Fault tolerance needs separate AZs |
| 2026-10-15 | Walkthrough 2 | NACL vs SG | Same subnet means NACLs can't differ per instance | Per-instance rules → security groups |
| 2026-10-15 | Walkthrough 3 | KMS vs ACM | ACM holds TLS certs, not data keys | Data keys → KMS |
| 2026-10-15 | Domain 1 practice | S3 protection | CRR doesn't protect against accidental delete | Versioning, MFA Delete, Object Lock |
