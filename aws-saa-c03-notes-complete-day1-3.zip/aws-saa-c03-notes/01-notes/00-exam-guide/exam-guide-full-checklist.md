# SAA-C03 Exam Guide: Full Checklist (all domains, every knowledge and skill item)

*Reworded checklist of the official Exam Guide v1.0. Tick each box when you can explain it and apply it to a scenario. Domain 1 is covered in depth in `01-domain-1-secure-architectures/`.*

## Exam mechanics
- [ ] Exam validates ability to use AWS to design solutions based on the **Well-Architected Framework**
- [ ] Design for **current business needs and future projected needs**
- [ ] Design **secure, resilient, high-performing, cost-optimized** architectures
- [ ] **Review existing solutions** and determine improvements
- [ ] Target candidate: **1+ year hands-on** designing AWS solutions
- [ ] Question types: **multiple choice** (1 correct + 3 distractors), **multiple response** (2+ correct out of 5+ options)
- [ ] Distractors are plausible answers for someone with incomplete knowledge
- [ ] **Unanswered = incorrect; no guessing penalty**, so always answer
- [ ] **50 scored + 15 unscored** questions (unscored are not identified)
- [ ] Pass/fail, **scaled 100-1,000, pass = 720**; scaling equates different exam forms
- [ ] **Compensatory** scoring: pass the overall exam, not each domain
- [ ] Section-level feedback exists only for failing candidates; use it with caution
- [ ] Domain weights: **30% / 26% / 24% / 20%** (scored content only)

## Domain 1: Design Secure Architectures (30%)
### 1.1 Design secure access to AWS resources
Knowledge
- [ ] Access controls and management across multiple accounts
- [ ] Federated access and identity services (IAM, AWS SSO)
- [ ] Global infrastructure (AZs, Regions)
- [ ] Security best practices (least privilege)
- [ ] Shared responsibility model

Skills
- [ ] Best practices for IAM users and root users (MFA)
- [ ] Flexible authorization model: users, groups, roles, policies
- [ ] Role-based access control: STS, role switching, cross-account access
- [ ] Multi-account security strategy: Control Tower, SCPs
- [ ] Appropriate use of resource policies
- [ ] When to federate a directory service with IAM roles

### 1.2 Design secure workloads and applications
Knowledge
- [ ] Application configuration and credentials security
- [ ] AWS service endpoints
- [ ] Controlling ports, protocols and network traffic
- [ ] Secure application access
- [ ] Security services and use cases (Cognito, GuardDuty, Macie)
- [ ] External threat vectors (DDoS, SQL injection)

Skills
- [ ] VPC architectures with security components (security groups, route tables, NACLs, NAT gateways)
- [ ] Network segmentation (public and private subnets)
- [ ] Integrating services to secure applications (Shield, WAF, SSO, Secrets Manager)
- [ ] Securing external connections to/from AWS (VPN, Direct Connect)

### 1.3 Determine appropriate data security controls
Knowledge
- [ ] Data access and governance
- [ ] Data recovery
- [ ] Data retention and classification
- [ ] Encryption and key management

Skills
- [ ] Align AWS technologies to compliance requirements
- [ ] Encrypt data at rest (KMS)
- [ ] Encrypt data in transit (ACM using TLS)
- [ ] Access policies for encryption keys
- [ ] Data backups and replications
- [ ] Policies for data access, lifecycle and protection
- [ ] Rotate encryption keys and renew certificates

## Domain 2: Design Resilient Architectures (26%)
### 2.1 Design scalable and loosely coupled architectures
Knowledge
- [ ] API creation and management (API Gateway, REST API)
- [ ] Managed services and use cases (Transfer Family, SQS, Secrets Manager)
- [ ] Caching strategies
- [ ] Microservice design principles (stateless vs stateful)
- [ ] Event-driven architectures
- [ ] Horizontal vs vertical scaling
- [ ] Edge accelerators (CDN)
- [ ] Migrating applications into containers
- [ ] Load balancing concepts (ALB)
- [ ] Multi-tier architectures
- [ ] Queuing and messaging (publish/subscribe)
- [ ] Serverless technologies and patterns (Fargate, Lambda)
- [ ] Storage types and characteristics (object, file, block)
- [ ] Container orchestration (ECS, EKS)
- [ ] When to use read replicas
- [ ] Workflow orchestration (Step Functions)

Skills
- [ ] Design event-driven, microservice and/or multi-tier architectures
- [ ] Determine scaling strategies for each component
- [ ] Determine services needed for loose coupling
- [ ] Determine when to use containers
- [ ] Determine when to use serverless
- [ ] Recommend compute, storage, networking and database technologies from requirements
- [ ] Use purpose-built services for workloads

### 2.2 Design highly available and/or fault-tolerant architectures
Knowledge
- [ ] Global infrastructure (AZs, Regions, Route 53)
- [ ] Managed services and use cases (Comprehend, Polly)
- [ ] Basic networking (route tables)
- [ ] DR strategies: backup and restore, pilot light, warm standby, active-active, **RPO**, **RTO**
- [ ] Distributed design patterns
- [ ] Failover strategies
- [ ] Immutable infrastructure
- [ ] Load balancing concepts
- [ ] Proxy concepts (RDS Proxy)
- [ ] Service quotas and throttling (including for a standby environment)
- [ ] Storage options and characteristics (durability, replication)
- [ ] Workload visibility (X-Ray)

Skills
- [ ] Automation strategies to ensure infrastructure integrity
- [ ] Services for HA/fault tolerance across Regions or AZs
- [ ] Metrics based on business requirements for HA
- [ ] Designs that mitigate single points of failure
- [ ] Strategies for data durability and availability (backups)
- [ ] Select an appropriate DR strategy
- [ ] Services that improve reliability of legacy/non-cloud-native apps (no app changes)
- [ ] Use purpose-built services

## Domain 3: Design High-Performing Architectures (24%)
### 3.1 High-performing and/or scalable storage
Knowledge
- [ ] Hybrid storage solutions
- [ ] Storage services and use cases (S3, EFS, EBS)
- [ ] Storage types and characteristics (object, file, block)

Skills
- [ ] Storage services/configurations that meet performance demands
- [ ] Storage that scales to accommodate future needs

### 3.2 High-performing and elastic compute
Knowledge
- [ ] Compute services and use cases (Batch, EMR, Fargate)
- [ ] Distributed computing with global infrastructure and edge services
- [ ] Queuing and messaging (pub/sub)
- [ ] Scalability capabilities (EC2 Auto Scaling, AWS Auto Scaling)
- [ ] Serverless technologies and patterns (Lambda, Fargate)
- [ ] Container orchestration (ECS, EKS)

Skills
- [ ] Decouple workloads so components scale independently
- [ ] Identify metrics and conditions for scaling actions
- [ ] Select compute options and features (EC2 instance types)
- [ ] Select resource type and size (for example Lambda memory)

### 3.3 High-performing database solutions
Knowledge
- [ ] Global infrastructure (AZs, Regions)
- [ ] Caching strategies and services (ElastiCache)
- [ ] Data access patterns (read-intensive vs write-intensive)
- [ ] Database capacity planning (capacity units, instance types, Provisioned IOPS)
- [ ] Database connections and proxies
- [ ] Database engines and use cases (heterogeneous vs homogeneous migrations)
- [ ] Database replication (read replicas)
- [ ] Database types and services (serverless, relational vs non-relational, in-memory)

Skills
- [ ] Configure read replicas
- [ ] Design database architectures
- [ ] Choose database engine (MySQL vs PostgreSQL)
- [ ] Choose database type (Aurora, DynamoDB)
- [ ] Integrate caching

### 3.4 High-performing and/or scalable network architectures
Knowledge
- [ ] Edge networking services (CloudFront, Global Accelerator)
- [ ] Network design (subnet tiers, routing, IP addressing)
- [ ] Load balancing concepts (ALB)
- [ ] Connection options (VPN, Direct Connect, PrivateLink)

Skills
- [ ] Create network topology for global, hybrid and multi-tier architectures
- [ ] Network configurations that scale for future needs
- [ ] Appropriate placement of resources
- [ ] Select the load balancing strategy

### 3.5 High-performing data ingestion and transformation
Knowledge
- [ ] Analytics and visualization services (Athena, Lake Formation, QuickSight)
- [ ] Data ingestion patterns (frequency)
- [ ] Data transfer services (DataSync, Storage Gateway)
- [ ] Data transformation services (Glue)
- [ ] Secure access to ingestion access points
- [ ] Sizes and speeds needed for business requirements
- [ ] Streaming data services (Kinesis)

Skills
- [ ] Build and secure data lakes
- [ ] Design data streaming architectures
- [ ] Design data transfer solutions
- [ ] Implement visualization strategies
- [ ] Select compute options for data processing (EMR)
- [ ] Select configurations for ingestion
- [ ] Transform data between formats (.csv to .parquet)

## Domain 4: Design Cost-Optimized Architectures (20%)
### 4.1 Cost-optimized storage
Knowledge
- [ ] Access options (S3 Requester Pays)
- [ ] Cost management features (cost allocation tags, multi-account billing)
- [ ] Cost tools (Cost Explorer, Budgets, Cost and Usage Report)
- [ ] Storage services and use cases (FSx, EFS, S3, EBS)
- [ ] Backup strategies
- [ ] Block storage options (HDD vs SSD volume types)
- [ ] Data lifecycles
- [ ] Hybrid storage options (DataSync, Transfer Family, Storage Gateway)
- [ ] Storage access patterns
- [ ] Storage tiering (cold tiering for object storage)
- [ ] Storage types and characteristics

Skills
- [ ] Storage strategies (batch vs individual uploads to S3)
- [ ] Right-size storage for a workload
- [ ] Lowest-cost data transfer to AWS storage
- [ ] Determine when storage auto scaling is needed
- [ ] Manage S3 object lifecycles
- [ ] Select backup/archival solution
- [ ] Select data migration service
- [ ] Select storage tier
- [ ] Select correct data lifecycle
- [ ] Select most cost-effective storage service

### 4.2 Cost-optimized compute
Knowledge
- [ ] Cost features and tools (tags, multi-account billing, Cost Explorer, Budgets, CUR)
- [ ] Global infrastructure (AZs, Regions)
- [ ] Purchasing options (Spot, Reserved Instances, Savings Plans)
- [ ] Distributed compute (edge processing)
- [ ] Hybrid compute (Outposts, Snowball Edge)
- [ ] Instance types, families, sizes (memory optimized, compute optimized, virtualization)
- [ ] Compute utilization optimization (containers, serverless, microservices)
- [ ] Scaling strategies (auto scaling, hibernation)

Skills
- [ ] Load balancing strategy: ALB (L7) vs NLB (L4) vs Gateway Load Balancer
- [ ] Scaling methods for elastic workloads (horizontal vs vertical, EC2 hibernation)
- [ ] Cost-effective compute (Lambda, EC2, Fargate)
- [ ] Required availability by workload class (production vs non-production)
- [ ] Select instance family
- [ ] Select instance size

### 4.3 Cost-optimized database
Knowledge
- [ ] Cost features and tools
- [ ] Caching strategies
- [ ] Data retention policies
- [ ] Database capacity planning (capacity units)
- [ ] Database connections and proxies
- [ ] Engines and use cases (heterogeneous vs homogeneous migrations)
- [ ] Replication (read replicas)
- [ ] Database types and services (relational vs non-relational, Aurora, DynamoDB)

Skills
- [ ] Backup and retention policies (snapshot frequency)
- [ ] Choose database engine (MySQL vs PostgreSQL)
- [ ] Cost-effective services (DynamoDB vs RDS, serverless)
- [ ] Cost-effective database types (time series, columnar)
- [ ] Migrate schemas and data to other locations or engines

### 4.4 Cost-optimized networks
Knowledge
- [ ] Cost features and tools
- [ ] Load balancing concepts (ALB)
- [ ] NAT gateways (NAT instance vs NAT gateway cost)
- [ ] Network connectivity (private lines, dedicated lines, VPNs)
- [ ] Routing, topology and peering (Transit Gateway, VPC peering)
- [ ] Network services (DNS)

Skills
- [ ] NAT gateway types (single shared vs one per AZ)
- [ ] Network connections (Direct Connect vs VPN vs internet)
- [ ] Routes that minimize transfer costs (Region to Region, AZ to AZ, private to public, Global Accelerator, VPC endpoints)
- [ ] Strategic need for CDN and edge caching
- [ ] Review workloads for network optimizations
- [ ] Throttling strategy
- [ ] Bandwidth allocation for network devices (single vs multiple VPNs, Direct Connect speed)
