# VPC Flow Logs
*Category: Networking / Monitoring | Scope: attached to a VPC, subnet or ENI | Domain 1 (Task 1.1, 1.2)*

## What it is
Captures **metadata about IP traffic** going to and from network interfaces.

## Key features and how it works
- Can be created at **VPC, subnet, or network interface** level; destinations **S3, CloudWatch Logs, Kinesis Data Firehose**.
- Records source/destination IP and port, protocol, bytes, packets, **ACCEPT or REJECT** action.
- **Not real time** and **no packet contents**. Does **not** log some traffic: DNS queries to the Amazon DNS server, DHCP, instance metadata (169.254.169.254), Windows license activation.
- Used to **troubleshoot security group/NACL** rules and as a **GuardDuty** data source.

## When the exam wants it
- "Why is traffic being rejected?", "audit network connections", "detect unusual traffic".

## Don't confuse with
- **CloudTrail** (API calls) and **traffic mirroring** (copies full packets).

## From the Domain 1 course
Named as a traceability tool with CloudTrail and CloudWatch.
