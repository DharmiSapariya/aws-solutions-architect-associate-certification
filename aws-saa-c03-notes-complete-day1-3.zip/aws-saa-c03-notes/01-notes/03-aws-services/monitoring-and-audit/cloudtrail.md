# AWS CloudTrail
*Category: Management and Governance | Scope: Regional events, trails can be multi-Region/organization-wide | Domain 1 (Task 1.1)*

## What it is
Records **API calls and account activity**: **who did what, when, from where**. The core audit trail for traceability.

## Key features and how it works
- **Event history** is on by default and shows the last **90 days** of management events.
- **Trails** deliver logs to **S3** (and optionally CloudWatch Logs); can be **multi-Region** and **organization trails** for all accounts.
- Event types: **management events** (control plane), **data events** (S3 object-level, Lambda invoke, DynamoDB items, optional and extra cost), **Insights events** (unusual activity), network activity events.
- **Log file integrity validation** (signed digest files) proves logs weren't tampered with; encrypt logs with **SSE-KMS**; **CloudTrail Lake** for queries.
- Send events to **EventBridge** for real-time automation (for example alert on root login).

## When the exam wants it
- "Who deleted this resource?", "audit API activity", "track changes by users/roles", "compliance logging".

## Don't confuse with
- **CloudWatch** (metrics/performance/logs), **Config** (resource configuration state/history), **VPC Flow Logs** (network traffic).

## From the Domain 1 course
Traceability tools alongside CloudWatch and VPC Flow Logs; the wrap-up asks about monitoring services **beyond** these three.
