# AWS Config
*Category: Management and Governance | Scope: Regional (aggregators for multi-Region/account) | Domain 1 (traceability, compliance)*

## What it is
Records **resource configurations and changes over time** and evaluates them against desired rules.

## Key features and how it works
- **Configuration history/inventory** of resources; **Config rules** (AWS managed or custom Lambda) check compliance continuously (for example "S3 buckets must be encrypted", "SG must not allow 0.0.0.0/0 on 22").
- **Conformance packs**, **auto-remediation** through Systems Manager Automation, **aggregators** for multi-account/Region.
- Feeds **Security Hub**, **Control Tower detective controls**, and **Audit Manager**.

## When the exam wants it
- "Track configuration changes", "evaluate compliance of resources", "what did this SG look like last week?".

## Don't confuse with
- **CloudTrail** (who made the API call), **GuardDuty** (threats).
