# Amazon CloudWatch (including Logs and EventBridge)
*Category: Management and Governance | Scope: Regional | Domain 1 (Task 1.1)*

## What it is
Monitoring and observability: **metrics, logs, alarms, dashboards** and automated reactions.

## Key features and how it works
- **Metrics**: standard EC2 metrics every 5 minutes (detailed monitoring 1 minute); custom metrics; **alarms** (including composite) trigger SNS, Auto Scaling, EC2 actions.
- **CloudWatch Logs** with **metric filters**, Logs Insights queries, subscription filters; the **CloudWatch agent** collects OS/app logs and memory/disk metrics.
- **Dashboards**, anomaly detection.
- **EventBridge** (formerly CloudWatch Events) routes events (including CloudTrail and GuardDuty findings) to Lambda, SNS, etc. for **automated response**.
- Security pattern: **CloudTrail → CloudWatch Logs → metric filter → alarm → SNS** (for example alert on root account use).

## When the exam wants it
- "Monitor performance/metrics", "alarm on thresholds", "centralize logs", "react to events".

## Don't confuse with
- **CloudTrail** (API audit), **Config** (configuration changes/compliance).
