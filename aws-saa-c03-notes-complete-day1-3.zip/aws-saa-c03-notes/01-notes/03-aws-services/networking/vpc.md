# Amazon VPC (Virtual Private Cloud)
*Category: Networking | Scope: **Regional** (one Region, one account); subnets are AZ-scoped | Domain 1 (Task 1.2) and Domains 2-4*

## What it is
Your logically isolated virtual network in AWS.

## Key features and how it works
- **CIDR block** from /16 to /28 (IPv4); secondary CIDRs allowed; **5 IP addresses reserved per subnet**.
- **Subnets**: each lives in **one AZ** (AZ-resilient scope). **Public subnet** = route to an **internet gateway (IGW)**; **private subnet** = no direct IGW route.
- **Route tables**: main and custom; each subnet associates with one. **Internet gateway**, **egress-only IGW** (IPv6 outbound), **NAT gateway**, virtual private gateway, transit gateway.
- **Default VPC** vs **custom VPC**:
  - Default: one per Region, 172.31.0.0/16, public subnet in each AZ, IGW and routes preconfigured, default SG, default NACL allowing all.
  - Custom: you design CIDR, subnets, routing; **nothing is open to the internet by default**; custom NACLs deny all until rules are added.
- Security layers: **security groups** (instance), **NACLs** (subnet), route tables, endpoints, Flow Logs.
- DHCP option sets, DNS support/hostnames, Elastic IPs.

## When the exam wants it
- Designing multi-tier networks, public/private segmentation, secure connectivity, scenario with on-prem over VPN/Direct Connect.

## Don't confuse with
- Region vs AZ scope: VPC regional, subnet AZ.

## From the Domain 1 course
"Know how to design, build and secure a VPC. Two types: default and custom. A VPC is a **regional** service; subnets are **AZ resilient**." Know CIDR, subnetting, routing, protocols, gateways.
