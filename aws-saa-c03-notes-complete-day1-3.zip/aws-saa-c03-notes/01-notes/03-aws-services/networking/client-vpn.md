# AWS Client VPN
*Category: Networking | Scope: Regional | Domain 1 (Task 1.2)*

## What it is
A managed **client-based (OpenVPN) VPN** for **individual remote users** to securely reach AWS and on-prem resources.

## Key features and how it works
- **Authentication**: Active Directory, **mutual (certificate) authentication**, **SAML** federation.
- **Authorization rules** control which networks each user group can reach; **split tunneling** option; associate with target subnets.
- Connection logs to CloudWatch Logs; scales automatically.

## When the exam wants it
- "Remote employees need secure access to VPC resources."

## Don't confuse with
- **Site-to-Site VPN** (office/data center to AWS).
