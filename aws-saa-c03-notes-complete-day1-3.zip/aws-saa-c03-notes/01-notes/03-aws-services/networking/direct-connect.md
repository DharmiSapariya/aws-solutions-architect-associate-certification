# AWS Direct Connect
*Category: Networking | Scope: Regional connection at a Direct Connect location | Domain 1 (Task 1.2), Domain 3-4*

## What it is
A **dedicated private network connection** from your premises to AWS, bypassing the public internet.

## Key features and how it works
- **Dedicated connections** at **1, 10 or 100 Gbps**; **hosted connections** from partners at lower speeds.
- **Virtual interfaces (VIFs)**: **private VIF** (to VPCs), **public VIF** (to AWS public services), **transit VIF** (to Transit Gateway). **Direct Connect gateway** reaches VPCs across Regions/accounts.
- **Consistent latency and bandwidth**, lower data transfer cost than internet; lead time can be **weeks**.
- **Not encrypted by default.** Add **VPN over Direct Connect** (IPsec on a public/transit VIF) or **MACsec** (supported dedicated connections) for encryption.
- **Resilience**: for high availability use **multiple connections at multiple locations** (maximum resiliency = two locations, redundant devices); common backup is a **Site-to-Site VPN**.

## When the exam wants it
- "Consistent high-throughput hybrid connectivity", "predictable performance", "reduce data transfer cost"; secure by adding encryption.

## Don't confuse with
- **Site-to-Site VPN** (internet-based, encrypted, quick).

## From the Domain 1 course
Know the **capacity, security and resilience options** for configuring Direct Connect along with VPN options.
