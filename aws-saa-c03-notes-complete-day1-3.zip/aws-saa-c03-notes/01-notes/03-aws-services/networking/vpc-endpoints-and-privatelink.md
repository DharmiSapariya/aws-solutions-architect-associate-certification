# VPC Endpoints and AWS PrivateLink
*Category: Networking | Scope: Regional/VPC | Domain 1 (Task 1.2)*

## What it is
Private connectivity to AWS services and your own services **without an internet gateway, NAT gateway, VPN or public IPs**.

## Key features and how it works
| Type | For | How | Notes |
|---|---|---|---|
| **Gateway endpoint** | **S3 and DynamoDB** only | A **route table target** (prefix list) | **Free**; works only from inside the VPC (not from on-prem or peered VPCs) |
| **Interface endpoint** (PrivateLink) | Most AWS services and partner/own services | **ENI with private IP** in your subnet, SG attachable, private DNS | Hourly + data cost; reachable from **on-prem via VPN/Direct Connect** |
| **Gateway Load Balancer endpoint** | Third-party appliances | Routes traffic via GWLB | Inspection use cases |
- **Endpoint policies** restrict which principals/resources the endpoint can use.
- **PrivateLink endpoint services**: a provider exposes a service behind an **NLB (or GWLB)**; consumers create an interface endpoint. **Unidirectional**, works with **overlapping CIDRs**, scales to **tens or hundreds of VPCs and accounts**.

## When the exam wants it
- "Access S3 privately from a private subnet without NAT" (gateway endpoint). "Expose a service to many VPCs/accounts without peering" (PrivateLink).

## Don't confuse with
- **VPC peering** (connects whole networks, non-transitive, overlapping CIDRs not allowed, exposes more), **Transit Gateway**.

## From the Domain 1 course
Endpoints are "gateway objects inside your VPC, similar to an internet gateway or NAT gateway". PrivateLink is "a secure and scalable way to expose your application to tens or hundreds of VPCs with no peering, internet gateway, NAT gateway". Exam guide knowledge: AWS service endpoints.
