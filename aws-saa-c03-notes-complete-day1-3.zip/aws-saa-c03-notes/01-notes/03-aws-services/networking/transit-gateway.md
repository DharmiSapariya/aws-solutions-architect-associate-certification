# AWS Transit Gateway
*Category: Networking | Scope: Regional (inter-Region peering supported) | Domain 1 (Task 1.2), Domain 3-4*

## What it is
A **regional network hub** that connects many VPCs and on-prem networks through a single gateway.

## Key features and how it works
- **Attachments**: VPCs, **Site-to-Site VPN**, **Direct Connect gateway**, peering to other transit gateways, Connect (SD-WAN).
- **Transit gateway route tables** allow segmentation (isolate dev from prod) and **transitive routing**.
- **ECMP** across VPN tunnels to increase aggregate VPN bandwidth; supports multicast; shareable with other accounts via **RAM**.
- Pricing per attachment-hour plus per GB processed.

## When the exam wants it
- "Connect dozens/hundreds of VPCs and on-prem simply", "replace a mesh of peering connections".

## Don't confuse with
- **VPC peering** (point-to-point), **PrivateLink** (service exposure).
