# AWS Site-to-Site VPN
*Category: Networking | Scope: Regional | Domain 1 (Task 1.2)*

## What it is
**Encrypted IPsec tunnels** between your on-premises network and AWS over the **public internet**.

## Key features and how it works
- Terminates on a **virtual private gateway (VGW)** or **Transit Gateway** at AWS and a **customer gateway** on your side.
- **Two tunnels per connection** (in different AZs) for redundancy; static or **BGP dynamic** routing.
- About **1.25 Gbps per tunnel**; use **TGW with ECMP** to aggregate bandwidth. **Accelerated VPN** uses Global Accelerator.
- Fast to set up, low cost; performance depends on the internet.

## When the exam wants it
- "Quick, encrypted connectivity to on-prem", "backup for Direct Connect".

## Don't confuse with
- **Client VPN** (individual users), **Direct Connect** (dedicated, not encrypted by default).

## From the Domain 1 course
Secure external connections using **private connections with AWS Site-to-Site VPNs, Client VPN and Direct Connect**; know capacity, security and resilience options.
