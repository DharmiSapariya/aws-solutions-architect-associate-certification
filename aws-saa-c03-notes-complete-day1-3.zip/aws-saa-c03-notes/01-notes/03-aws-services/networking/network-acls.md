# Network ACLs (NACLs)
*Category: Networking | Scope: VPC subnet level | Domain 1 (Task 1.2)*

## What it is
A **stateless firewall at the subnet boundary**.

## Key features and how it works
- **Allow and Deny** rules, numbered **1 to 32766**, evaluated **lowest number first**, **first match wins**; final `*` rule denies everything unmatched.
- **Stateless**: you must explicitly allow **return traffic**, including **ephemeral ports (1024-65535)**.
- One NACL per subnet; one NACL can cover many subnets. **Default NACL allows all** inbound/outbound; a **newly created custom NACL denies all** until rules are added.
- Applies to traffic entering/leaving the subnet, not between instances in the same subnet.

## When the exam wants it
- "Block a specific IP/CIDR", "extra subnet-level layer", defense in depth.

## Don't confuse with
- **Security groups** (stateful, allow only, instance level).

## Gotchas
Forgetting ephemeral ports or the outbound rule is the classic cause of broken connections; rule numbering gaps (100, 200) leave room to insert.
