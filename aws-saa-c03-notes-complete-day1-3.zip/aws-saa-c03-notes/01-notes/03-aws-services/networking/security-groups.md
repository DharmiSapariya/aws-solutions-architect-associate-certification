# Security Groups
*Category: Networking | Scope: VPC (applied to ENIs) | Domain 1 (Task 1.2)*

## What it is
A **stateful virtual firewall at the instance/network-interface level**.

## Key features and how it works
- **Allow rules only** (no deny); anything not allowed is denied. Default: **no inbound**, **all outbound** allowed.
- **Stateful**: return traffic for an allowed connection is automatically allowed.
- Sources/destinations: CIDR, another **security group**, or a **prefix list**; **referencing SGs** is the standard way to chain tiers (ALB SG → app SG → DB SG).
- **All rules are evaluated** before a decision; changes apply **immediately**.
- Multiple SGs can attach to one ENI (rules combine); SGs are Region/VPC-specific. The **default SG** allows inbound from members of itself and all outbound.

## When the exam wants it
- Control ports/protocols/sources to instances; tier-to-tier access; "only the app tier may reach the database on 3306".

## Don't confuse with
- **NACL** (stateless, subnet, allow+deny, numbered order).

## Gotchas
Cannot block a specific IP (use NACL/WAF); avoid 0.0.0.0/0 on admin ports.
