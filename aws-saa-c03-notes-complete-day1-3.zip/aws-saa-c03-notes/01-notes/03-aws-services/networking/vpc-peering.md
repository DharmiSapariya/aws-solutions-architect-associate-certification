# VPC Peering
*Category: Networking | Scope: Regional/inter-Region, cross-account | Domain 1 (Task 1.2)*

## What it is
A **private, 1-to-1 network connection between two VPCs** using the AWS backbone.

## Key features and how it works
- Works **same Region, cross-Region and cross-account**.
- **CIDR blocks must not overlap**; add **routes in both VPCs**; update security groups/NACLs.
- **Not transitive**: A↔B and B↔C does **not** mean A↔C. No edge-to-edge routing through a peer's IGW/NAT/VPN.
- No single point of failure or bandwidth bottleneck; data stays off the public internet; traffic between peers in the same Region can reference peer security groups.

## When the exam wants it
- Simple connection between two or a few VPCs.

## Don't confuse with
- **Transit Gateway** (hub-and-spoke, transitive) and **PrivateLink** (expose a single service).

## From the Domain 1 course
Peering "adds management overhead as you scale and **exposes other applications** in the peered VPCs".
