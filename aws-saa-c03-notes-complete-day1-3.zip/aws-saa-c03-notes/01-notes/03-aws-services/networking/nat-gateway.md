# NAT Gateway (and NAT instance)
*Category: Networking | Scope: **AZ-scoped** | Domain 1 (Task 1.2), Domain 4 (cost)*

## What it is
Lets resources in **private subnets** initiate **outbound** connections to the internet (or other networks) while blocking inbound connections from the internet.

## Key features and how it works
- Lives in a **public subnet**, uses an **Elastic IP** (public NAT gateway); a **private NAT gateway** has no EIP, for private/cross-network use.
- Private subnet route table: `0.0.0.0/0 → NAT gateway`; NAT subnet route table: `0.0.0.0/0 → IGW`.
- **Managed, scales automatically** (up to 100 Gbps); **no security group** (NACL applies to its subnet).
- **HA design**: one NAT gateway **per AZ**, each AZ's private route table pointing to its own. A single shared NAT is cheaper but an AZ-failure risk and cross-AZ data charges.
- **NAT instance**: self-managed EC2, disable source/dest check, you handle HA/scaling; legacy.
- IPv6 uses an **egress-only internet gateway**, not NAT.

## When the exam wants it
- "Private instances need to download patches but must not be reachable from the internet."

## Don't confuse with
- **IGW** (two-way public access), **VPC endpoints** (reach AWS services without NAT).

## Cost note
Hourly charge plus per-GB processing; using **gateway endpoints for S3/DynamoDB** avoids NAT charges (Domain 4).
