# AWS Firewall Manager
*Category: Security | Scope: Regional/org-wide administration | Domain 1 (appendix service)*

## What it is
Central management of firewall rules **across all accounts in an AWS Organization**.

## Key features and how it works
- Manages **WAF** rules, **Shield Advanced** protections, **security group** policies, **Network Firewall** and **Route 53 Resolver DNS Firewall**.
- Requires **Organizations** and **AWS Config**; a designated **Firewall Manager administrator account**.
- Automatically applies policies to new accounts/resources and flags non-compliant ones.

## When the exam wants it
- "Enforce WAF/SG rules consistently across many accounts."

## Don't confuse with
- **WAF** (the firewall itself), **Organizations SCPs** (permission limits).
