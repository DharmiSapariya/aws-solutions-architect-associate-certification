# AWS Secrets Manager
*Category: Security | Scope: Regional (cross-Region replication supported) | Domain 1 (Task 1.2)*

## What it is
Stores, retrieves and **automatically rotates secrets** such as database credentials, API keys and tokens.

## Key features and how it works
- **Automatic rotation** on a schedule (interval in days) using Lambda; **built-in rotation** for RDS, Aurora, Redshift, DocumentDB.
- Encrypted with **KMS**; fine-grained **IAM and resource policies**; **versioning** (AWSCURRENT / AWSPREVIOUS).
- **Cross-Region secret replication**; audit with CloudTrail.
- Retrieve through the API/SDK so applications never hard-code credentials. Priced per secret per month plus API calls.

## When the exam wants it
- "Store credentials securely **and rotate them automatically**", "high-volume secret access with rotation" → **Secrets Manager**.

## Don't confuse with
- **Parameter Store** (config and secrets, no native rotation, free standard tier), **KMS** (keys, not secrets).

## From the Domain 1 course
"If you need high-volume access with **automatic credential rotation**, choose **Secrets Manager**, designed to store secrets and **force rotation at a chosen interval of days**." Also Domain 2 guide mentions it as a managed service.
