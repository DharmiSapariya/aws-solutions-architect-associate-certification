# AWS Certificate Manager (ACM)
*Category: Security | Scope: Regional (CloudFront certificates must be in us-east-1) | Domain 1 (Task 1.3)*

## What it is
Provision, manage and **renew SSL/TLS certificates** for encryption in transit.

## Key features and how it works
- **Public certificates** (free) and **private certificates** via **ACM Private CA** (paid).
- **Validation**: **DNS** (recommended, enables auto-renewal) or email.
- **Managed renewal**: ACM-issued certificates renew automatically when validation remains valid; **imported certificates are not auto-renewed** (you renew them); EventBridge events warn of expiry.
- Deploy to **ELB, CloudFront, API Gateway** and similar integrated services. Public ACM certs aren't installed directly on EC2 instances.

## When the exam wants it
- "Enable HTTPS/TLS on an ALB/CloudFront/API Gateway with automatic renewal" → **ACM**.

## Don't confuse with
- **KMS** (data encryption keys), **IAM server certificates** (legacy).

## From the Domain 1 course
"Know how to use AWS Certificate Manager to encrypt data in transit and how certificates are renewed." Exam guide skill: encrypt data in transit (ACM using TLS); rotate keys and renew certificates.
