# AWS WAF
*Category: Security | Scope: Regional (CloudFront web ACLs are global, created in us-east-1) | Domain 1 (Task 1.2)*

## What it is
A **layer 7 (HTTP/HTTPS) web application firewall** that filters requests to your web apps/APIs.

## Key features and how it works
- **Web ACLs** contain **rules** and **rule groups** (AWS Managed Rules, Marketplace rules, your own). Actions: **Allow, Block, Count, CAPTCHA, Challenge**.
- Match on IP sets, geography, headers, URI, query strings, body size, **SQL injection**, **cross-site scripting (XSS)**, regex.
- **Rate-based rules** for brute force/HTTP floods; **Bot Control**; account takeover/fraud prevention.
- **Can only be associated with certain resources**: **CloudFront, Application Load Balancer, API Gateway (REST), AppSync, Cognito user pools** and a few others. **Not directly with NLB or EC2.**
- Logging to S3, CloudWatch Logs, Kinesis Data Firehose. Centrally managed with **Firewall Manager**.

## When the exam wants it
- "Block SQL injection/XSS", "block IPs/countries at the app layer", "rate limit requests" → **WAF**.

## Don't confuse with
- **Shield** (DDoS), **Security groups/NACLs** (network layer), **Network Firewall**.

## From the Domain 1 course
"AWS WAF can only be deployed on certain AWS services such as **Application Load Balancers, API Gateway, and CloudFront**." Threat vectors in the exam guide: DDoS, SQL injection.
