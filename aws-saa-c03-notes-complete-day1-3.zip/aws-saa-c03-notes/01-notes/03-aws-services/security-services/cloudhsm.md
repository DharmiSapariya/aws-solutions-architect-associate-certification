# AWS CloudHSM
*Category: Security | Scope: Regional (cluster across AZs) | Domain 1 (Task 1.3)*

## What it is
**Dedicated, single-tenant hardware security modules (HSMs)** in your VPC where **you** generate and control the keys.

## Key features and how it works
- **FIPS 140-2 Level 3** validated hardware; **AWS cannot access your keys**.
- You manage **HSM users, keys and backups**; deploy a **cluster across multiple AZs** for high availability.
- Standard APIs: **PKCS#11, JCE, CNG**.
- Use cases: strict regulatory/contractual requirements, **SSL/TLS offload**, **TDE for databases (such as Oracle)**, code signing, and as a **KMS custom key store**.

## When the exam wants it
- "Dedicated HSM", "single-tenant", "customer exclusively controls keys, compliance requires it".

## Don't confuse with
- **KMS** (managed, multi-tenant, default choice, integrated with AWS services).

## From the Domain 1 course
Wrap-up: know **when to choose KMS or CloudHSM**; they can be used together (KMS custom key store).
