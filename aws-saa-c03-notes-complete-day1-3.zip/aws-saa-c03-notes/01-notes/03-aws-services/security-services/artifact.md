# AWS Artifact
*Category: Security, Identity, Compliance | Scope: Global | Domain 1 (Task 1.3) | Cost: free*

## What it is
A **self-service central repository** for AWS **security and compliance reports** and **online agreements**.

## Key features and how it works
- **Artifact Reports**: SOC, ISO, PCI and other third-party audit reports.
- **Artifact Agreements**: review/accept agreements such as the **BAA (HIPAA)** and NDAs, per account or organization.
- Supports your own audits by providing evidence about AWS's side of the **shared responsibility model**.

## When the exam wants it
- "Download AWS compliance reports/audit artifacts", "accept a BAA" → **Artifact**.

## Don't confuse with
- **Audit Manager** (collects evidence about *your* usage), **Config** (your resource compliance).

## From the Domain 1 course
"Understand AWS Artifact and how to use the **self-service central repository** for AWS security and compliance reports and online agreements."
