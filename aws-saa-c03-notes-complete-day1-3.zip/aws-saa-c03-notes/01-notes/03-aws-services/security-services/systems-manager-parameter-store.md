# AWS Systems Manager (focus: Parameter Store and Session Manager)
*Category: Management and Governance | Scope: Regional | Domain 1 (Task 1.2)*

## What it is
A suite for operating AWS and hybrid resources. For Domain 1 the key parts are **Parameter Store** and **Session Manager**.

## Key features and how it works
- **Parameter Store**: hierarchical storage for configuration data and secrets. Types: **String, StringList, SecureString** (encrypted with KMS). **Standard** tier (free, 4 KB values) and **Advanced** tier (larger values, more parameters, policies such as expiration). Versioning, IAM control, CloudTrail audit. **No built-in automatic rotation.**
- **Session Manager**: browser/CLI shell access to instances through IAM, **no inbound ports, no bastion host, no SSH keys**, with session logging to S3/CloudWatch.
- Other tools: Run Command, Patch Manager, State Manager, Automation, Inventory.

## When the exam wants it
- "Store config/parameters cheaply", "reference secrets in apps without rotation needs" → Parameter Store. "Secure shell access without opening port 22" → Session Manager.

## Don't confuse with
- **Secrets Manager** (rotation, higher cost, built for secrets).

## From the Domain 1 course
Course compares **Secrets Manager vs Systems Manager Parameter Store** and lists Parameter Store among services to secure applications.
