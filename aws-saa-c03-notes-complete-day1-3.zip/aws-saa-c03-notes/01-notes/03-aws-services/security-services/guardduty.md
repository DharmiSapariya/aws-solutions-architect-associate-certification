# Amazon GuardDuty
*Category: Security | Scope: Regional | Domain 1 (Task 1.2)*

## What it is
Intelligent **threat detection** that continuously analyzes logs and activity to find compromised resources, malicious activity and unauthorized behavior.

## Key features and how it works
- Core data sources, **no agents needed**: **CloudTrail** (management and S3 data events), **VPC Flow Logs**, **DNS logs**. Additional protection plans: S3, EKS audit logs/runtime, Lambda, RDS login activity, EBS **malware protection**.
- Uses machine learning, anomaly detection and threat intelligence feeds.
- **Findings** with severity; send to **EventBridge**, **Security Hub**, Detective for automated remediation (for example Lambda).
- **Multi-account** via Organizations (delegated administrator), trusted IP lists and threat lists, suppression rules.

## When the exam wants it
- "Detect compromised EC2 instance, crypto mining, unusual API calls, port scanning, exfiltration" → **GuardDuty**.

## Don't confuse with
- **Macie** (sensitive data in S3), **Inspector** (vulnerabilities), **Detective** (investigate), **Config** (config compliance), **CloudTrail** (raw API logs).

## From the Domain 1 course
Named in the exam guide (Task 1.2 knowledge) with Cognito and Macie; expect scenario-based use-case questions.
