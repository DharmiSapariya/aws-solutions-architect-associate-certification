# Amazon Macie
*Category: Security | Scope: Regional | Domain 1 (Task 1.2)*

## What it is
Uses **machine learning and pattern matching** to **discover, classify and protect sensitive data stored in Amazon S3**.

## Key features and how it works
- **Managed data identifiers** for PII (names, addresses, email, SSN, driver's license, passport, date of birth), financial data (bank/credit card numbers) and credentials; **custom data identifiers** (regex/keywords).
- Sensitive data discovery jobs and **automated sensitive data discovery**.
- Evaluates **bucket posture**: public access, encryption, sharing outside the org.
- **Findings** go to EventBridge and Security Hub; multi-account via Organizations.

## When the exam wants it
- "Find/protect **PII** in S3", "classify data", "data loss risk in buckets" → **Macie**.

## Don't confuse with
- **GuardDuty** (threat detection from logs), **KMS** (encrypts but doesn't find data), **Inspector**.

## From the Domain 1 course
The course's exact exam example: *which AWS service helps secure PII?* → Macie. PII listed: name, address, email, SSN, driver license, passport, date of birth, bank account, credit card.
