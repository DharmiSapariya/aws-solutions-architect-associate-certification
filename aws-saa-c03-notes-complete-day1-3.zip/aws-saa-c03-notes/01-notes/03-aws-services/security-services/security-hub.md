# AWS Security Hub
*Category: Security | Scope: Regional (cross-Region aggregation available) | Domain 1 (appendix service)*

## What it is
A **central place to view and manage security findings** and check compliance posture across accounts.

## Key features and how it works
- Aggregates findings from **GuardDuty, Inspector, Macie, Firewall Manager, Config, IAM Access Analyzer** and partner products, in a standard format (**ASFF**).
- Runs automated checks against standards: **AWS Foundational Security Best Practices, CIS, PCI DSS**.
- **Multi-account** via Organizations; automate with **EventBridge** and Lambda. Needs **AWS Config** enabled.

## When the exam wants it
- "Single dashboard of security findings/compliance across accounts."

## Don't confuse with
- **GuardDuty** (a finding source), **Config** (resource compliance), **Detective** (investigation).
