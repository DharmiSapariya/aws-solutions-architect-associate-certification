# AWS Network Firewall
*Category: Security | Scope: Regional (deployed per VPC/AZ) | Domain 1 (appendix service)*

## What it is
A managed **network firewall and intrusion prevention** service for VPCs.

## Key features and how it works
- **Stateless and stateful** rule engines, **Suricata-compatible** rules, **domain/URL filtering**, intrusion prevention (IPS), deep packet inspection.
- Deployed via **firewall endpoints in dedicated subnets**; route tables steer traffic through the endpoints (internet, between VPCs, to on-prem).
- Centrally managed with **Firewall Manager**; logs to S3/CloudWatch/Firehose.

## When the exam wants it
- "Inspect and filter VPC traffic (IPS, domain filtering, deep packet inspection) beyond security groups/NACLs."

## Don't confuse with
- **WAF** (L7 web requests), **security groups/NACLs** (simple rules), **Shield**.
