# Amazon Inspector
*Category: Security | Scope: Regional | Domain 1 (appendix service)*

## What it is
Automated, continuous **vulnerability management**.

## Key features and how it works
- Scans **EC2 instances** (via SSM agent), **ECR container images** and **Lambda functions** for software vulnerabilities (CVEs) and unintended **network exposure**.
- Risk scoring and prioritization; findings to **Security Hub** and **EventBridge**; multi-account via Organizations.

## When the exam wants it
- "Scan workloads for vulnerabilities/CVEs automatically."

## Don't confuse with
- **GuardDuty** (active threats), **Macie** (data), **Config** (configuration compliance).
