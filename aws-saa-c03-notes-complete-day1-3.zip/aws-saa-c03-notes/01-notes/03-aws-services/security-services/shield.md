# AWS Shield
*Category: Security | Scope: Global service (protects regional and global resources) | Domain 1 (Task 1.2)*

## What it is
Managed **DDoS protection**.

## Key features and how it works
| | Shield Standard | Shield Advanced |
|---|---|---|
| Cost | **Free**, automatic for all customers | **Paid** subscription (commitment) |
| Protection | Common **L3/L4** attacks (SYN/UDP floods, reflection) | Larger, more sophisticated L3/L4 and **L7** (with WAF) |
| Extras | Always-on detection | **24/7 Shield Response Team**, **cost protection** for scaling charges from attacks, near-real-time metrics, health-based detection, **WAF included** for protected resources |
| Resources | CloudFront, Route 53 and more by default | **CloudFront, Route 53, Global Accelerator, ELB (ALB/CLB/NLB), Elastic IPs** |

## When the exam wants it
- "Protect from DDoS" → **Shield (Standard by default; Advanced for enhanced/higher-value apps)**. DDoS + web layer → Shield + WAF + CloudFront.

## Don't confuse with
- **WAF** (L7 request filtering, SQLi/XSS), **Network Firewall** (VPC traffic filtering).

## From the Domain 1 course
"Understand the difference between **Shield Standard and Shield Advanced**. Know when to choose one security service over another (DDoS vs SQL injection)."
