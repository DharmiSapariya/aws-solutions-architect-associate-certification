# AWS Audit Manager
*Category: Security, Identity, Compliance | Scope: Regional | Domain 1 (appendix service)*

## What it is
**Continuously collects evidence** from your AWS usage to simplify audits and compliance reporting.

## Key features and how it works
- **Prebuilt frameworks** (for example PCI DSS, HIPAA, SOC 2, GDPR, CIS), custom frameworks.
- Assessments gather evidence from **CloudTrail, Config, Security Hub** and API calls; produces **audit-ready reports**; delegation to reviewers.

## When the exam wants it
- "Automate evidence collection for audits."

## Don't confuse with
- **Artifact** (AWS's own reports).
