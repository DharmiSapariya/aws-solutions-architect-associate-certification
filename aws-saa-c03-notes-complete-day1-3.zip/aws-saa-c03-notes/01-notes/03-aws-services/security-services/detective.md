# Amazon Detective
*Category: Security | Scope: Regional | Domain 1 (appendix service)*

## What it is
Helps **investigate** security findings and find the **root cause** quickly.

## Key features and how it works
- Builds a **behavior graph** automatically from CloudTrail, VPC Flow Logs, GuardDuty findings and EKS audit logs.
- Visualizations and timelines for entities (IPs, users, roles, instances).
- Integrates with GuardDuty and Security Hub findings.

## When the exam wants it
- "Investigate/analyze root cause of a security finding or suspicious activity."

## Don't confuse with
- **GuardDuty** (detects), **Security Hub** (aggregates), **CloudTrail** (raw logs).
