# AWS Resource Access Manager (RAM)
*Category: Security, Identity, Compliance | Scope: Regional | Domain 1/2 (appendix service)*

## What it is
Share AWS resources **securely across accounts** (or within an Organization) **without duplicating** them.

## Key features and how it works
- Shareable resources include **VPC subnets** (VPC sharing), **Transit Gateway**, Route 53 Resolver rules, License Manager configurations, and more.
- Works with **Organizations**: share with accounts, OUs or the whole org without per-account invitations.
- Participants use the shared resource as if local but the owner retains control; permissions managed through RAM permissions.

## When the exam wants it
- "Share a Transit Gateway/subnets with other accounts", "avoid duplicating resources across accounts".

## Don't confuse with
- **Cross-account IAM roles** (access via assuming a role) and **VPC peering** (connect networks).
