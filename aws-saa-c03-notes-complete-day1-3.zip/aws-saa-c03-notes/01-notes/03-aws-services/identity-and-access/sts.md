# AWS Security Token Service (STS)
*Category: Security, Identity, Compliance | Scope: global endpoint plus regional endpoints | Domain 1 (Task 1.1) | Cost: free*

## What it is
Issues **temporary, limited-privilege credentials** (access key, secret key, session token) for IAM users or federated users.

## Key features and how it works
- **AssumeRole**: same-account or **cross-account** role assumption; role has a **trust policy** naming who may assume it.
- **AssumeRoleWithSAML**: enterprise IdP federation. **AssumeRoleWithWebIdentity**: web/social IdPs (Cognito identity pools use this pattern).
- **GetSessionToken**: temporary credentials for a user, often to enforce **MFA** on API calls. **GetFederationToken**: custom federation brokers.
- Session duration: default 1 hour for roles (configurable up to 12 hours); the credentials expire automatically.
- **External ID** protects third-party cross-account access (confused deputy problem).
- **Role chaining** and **role switching** (console) are supported.

## When the exam wants it
- Cross-account access, temporary credentials, federation, "avoid long-term keys", role switching.

## Don't confuse with
- **IAM** (defines the roles/policies) vs **STS** (issues the temporary credentials).

## Gotchas
Credentials can't be revoked early except by changing the role policy/deny with a time condition; the calling principal needs `sts:AssumeRole` permission **and** the role's trust policy must allow it.

## From the Domain 1 course
"Understand how to use AWS STS **within and across accounts**, and how roles are used with federation." Exam guide skill: role-based access control with STS, role switching, cross-account access.
