# AWS Directory Service
*Category: Security, Identity, Compliance | Scope: Regional | Domain 1 (Task 1.1)*

## What it is
Managed directory options so AWS workloads can use **Active Directory** for authentication, and so AD users can be federated into AWS.

## Key features and how it works
| Option | What it is | Use when |
|---|---|---|
| **AWS Managed Microsoft AD** | Real Microsoft AD running in AWS, can form **trusts** with on-prem AD | Windows workloads, full AD features, hybrid with trust |
| **AD Connector** | **Proxy** that redirects requests to your **on-prem AD**, nothing stored in AWS | Use existing on-prem AD without hosting a directory in AWS |
| **Simple AD** | Basic, Samba-based AD-compatible directory, standalone | Small/simple needs, no advanced AD features or trusts |
- Also **Cognito** uses a different directory concept (user pools); do not mix them up.
- Can be an **identity source for IAM Identity Center**; supports domain-joining EC2, RDS for SQL Server auth, WorkSpaces.

## When the exam wants it
- "Extend/connect on-prem AD", "domain-join EC2 Windows", "federate AD to AWS" → Directory Service (usually Managed AD or AD Connector).

## Gotchas
AD Connector needs connectivity (VPN/Direct Connect) to on-prem AD; Simple AD can't trust on-prem AD.

## From the Domain 1 course
"Know different ways to federate into AWS, AWS SSO and different use cases for AWS Directory Service."
