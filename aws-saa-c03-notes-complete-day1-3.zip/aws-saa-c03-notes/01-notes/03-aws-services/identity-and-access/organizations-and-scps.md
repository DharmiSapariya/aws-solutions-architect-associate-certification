# AWS Organizations and Service Control Policies (SCPs)
*Category: Management and Governance | Scope: Global (management account) | Domain 1 (Task 1.1)*

## What it is
Central management of **multiple AWS accounts**: grouping, governance and **consolidated billing**.

## Key features and how it works
- **Management account** (formerly master), **member accounts**, **organizational units (OUs)** in a hierarchy under the **root**.
- **SCPs**: guardrails that define the **maximum permissions** for accounts/OUs. They **never grant** permissions; effective permission = what the identity policy allows **and** every SCP up the tree allows.
- Default `FullAWSAccess` SCP is attached; use a **deny-list** (block specific actions) or **allow-list** (explicitly allow only some) strategy.
- SCPs apply to **all principals in member accounts including the account root user**, but **not to the management account** and not to service-linked roles.
- Other policy types: tag policies, backup policies, AI services opt-out policies.
- Consolidated billing, volume discounts, delegated administrators for services (GuardDuty, Security Hub, Config).
- Create or invite accounts; enable trusted access for services (Identity Center, CloudTrail organization trails, RAM).

## When the exam wants it
- "Prevent any account from using a Region/service", "enforce guardrails across many accounts", "least privilege in a multi-account environment" → **Organizations + SCPs**.

## Don't confuse with
- **Control Tower** (automated landing zone built on Organizations), **IAM policies** (grant), **Service Catalog** (approved products).

## Gotchas
An SCP alone doesn't give access; SCP deny beats any IAM allow; management account is exempt.

## From the Domain 1 course
Exam guide skill: "designing a security strategy for multiple AWS accounts (AWS Control Tower, SCPs)". Wrap-up asks Control Tower vs Service Catalog vs Organizations for least privilege.
