# AWS IAM Identity Center (formerly AWS Single Sign-On)
*Category: Security, Identity, Compliance | Scope: enabled in one (home) Region, used across accounts | Domain 1 (Task 1.1, 1.2)*

## What it is
Central **workforce single sign-on** to **multiple AWS accounts and applications**. Renamed from **AWS SSO**; the exam guide v1.0 and the course still say "AWS SSO".

## Key features and how it works
- **Identity source**: built-in Identity Center directory, **Active Directory** (via AWS Managed Microsoft AD or AD Connector), or an **external IdP** (SAML 2.0, SCIM provisioning).
- **Permission sets**: reusable templates of permissions assigned to users/groups per account; Identity Center creates the IAM roles in member accounts.
- Integrates with **AWS Organizations** for multi-account assignment.
- Users sign in once via the **access portal** and get **temporary credentials** (no long-term IAM user keys).
- SSO to cloud applications (SAML apps) as well as AWS accounts.
- MFA, session duration, attribute-based access control.

## When the exam wants it
- "Employees need SSO to many AWS accounts", "centralize access for the workforce", "federate corporate directory with AWS" → **IAM Identity Center**.

## Don't confuse with
- **Cognito** = customers of your app. **IAM users** = discouraged for humans at scale. **Directory Service** = hosts/connects to AD.

## Gotchas
Not for application end-users; permission sets are applied through roles it creates; pair with Organizations.

## From the Domain 1 course
Part of the "different ways to federate into AWS" and "integrating services to secure applications" lists; exam guide skill: determine when to federate a directory service with IAM roles.
