# AWS Identity and Access Management (IAM)
*Category: Security, Identity, Compliance | Scope: **Global** | Domain 1 (Tasks 1.1, 1.3) | Cost: free*

## What it is
The service that controls **who (authentication) can do what (authorization) on which AWS resources**. IAM data is stored once and applies across **all Regions**.

## Key features and how it works
- **Root user**: created with the account, full unrestricted access. Protect with MFA, no access keys, use only for tasks that require it.
- **Users** (long-term credentials: password, access keys), **groups** (collections of users, cannot be nested), **roles** (assumed, temporary credentials).
- **Policies**: JSON documents. Identity-based (attach to user/group/role), resource-based (attach to resource, has `Principal`), plus SCPs, permissions boundaries, session policies, trust policies.
- **Statement elements**: Version, Statement, Sid, Effect, Principal, Action/NotAction, Resource/NotResource, Condition.
- **Evaluation**: implicit deny by default → explicit deny always wins → explicit allow required. Cross-account needs allow on both sides.
- **MFA**, password policy, **credential report**, **access advisor** (last-used), **IAM Access Analyzer** (external/unused access findings, policy generation), **policy simulator**.
- **Identity federation**: SAML 2.0 and OpenID Connect providers to let outside identities assume roles.
- **Instance profile / service roles**: how EC2, Lambda and other services get permissions without stored keys.
- **Attribute-based access control (ABAC)** using tags in conditions.

## When the exam wants it
- Any "who can access what" scenario; least privilege; cross-account access (role + trust policy); giving an EC2 instance/Lambda access to S3/DynamoDB (role, never keys); temporary elevated access.

## Don't confuse with
- **IAM Identity Center** (workforce SSO across accounts) and **Cognito** (customer app users). IAM itself is the permissions engine they all use.

## Security best practices
MFA everywhere privileged; no root access keys; least privilege; roles over long-term keys; rotate and remove unused keys; use groups; use conditions (MFA, source IP, encryption required); review with Access Analyzer.

## Gotchas
New identities start with **no permissions**; groups can't be a Principal; a group can't contain groups; an explicit deny in any applicable policy overrides everything; permission changes are eventually consistent.

## From the Domain 1 course
IAM is a **global** service; root user compromise = whole environment compromised; never hard-code credentials; know identity vs resource policies and the evaluation logic.
