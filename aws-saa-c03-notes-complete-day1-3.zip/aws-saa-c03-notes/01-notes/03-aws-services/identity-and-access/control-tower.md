# AWS Control Tower
*Category: Management and Governance | Scope: home Region plus governed Regions | Domain 1 (Task 1.1)*

## What it is
Automates setting up a **well-architected, secure multi-account environment (landing zone)** with built-in governance, on top of Organizations.

## Key features and how it works
- **Landing zone**: baseline OUs and accounts (management, **log archive**, **audit**), centralized logging (CloudTrail, Config), IAM Identity Center for access.
- **Controls (guardrails)**: **preventive** (implemented with SCPs), **detective** (implemented with AWS Config rules), and proactive (CloudFormation hooks). Mandatory, strongly recommended and elective categories.
- **Account Factory** (uses Service Catalog) to provision new accounts with a standard baseline.
- **Dashboard** for compliance status across accounts/OUs.

## When the exam wants it
- "Set up a secure multi-account environment quickly with best practices/guardrails", "govern accounts with minimal effort" → **Control Tower**.

## Don't confuse with
- **Organizations** (the primitive: accounts, OUs, SCPs), **Service Catalog**, **Security Hub** (findings aggregation).

## From the Domain 1 course
Listed in the exam guide skill for multi-account strategy and named in the wrap-up question; know it with Organizations and SCPs.
