# AWS Service Catalog
*Category: Management and Governance | Scope: Regional | Domain 1 (wrap-up mention)*

## What it is
Lets administrators create **portfolios of approved products** (CloudFormation templates and more) that users can launch with **pre-approved configurations**.

## Key features and how it works
- **Products** and **portfolios**, shared across accounts/organization; **launch constraints** let users launch resources through a launch role so they **don't need broad permissions** themselves (supports least privilege).
- Enforces standards, tagging and compliance; used by **Control Tower Account Factory**.

## When the exam wants it
- "Allow teams to self-provision only approved resources/architectures."

## Don't confuse with
- **Organizations/SCPs** (limit permissions) and **Control Tower** (landing zone). Service Catalog standardizes *what gets deployed*.

## From the Domain 1 course
Listed as one of the three candidates in the wrap-up question about least privilege in a multi-account environment.
