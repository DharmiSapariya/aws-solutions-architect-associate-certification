# Amazon Cognito
*Category: Security, Identity, Compliance | Scope: Regional | Domain 1 (Task 1.2)*

## What it is
Authentication, authorization and user management for **web and mobile apps** (customers/app users), with SSO/identity federation.

## Key features and how it works
- **User pools**: a **user directory** with sign-up/sign-in, hosted UI, **JWT tokens (ID, access, refresh)**, MFA, password policies, **social IdPs** (Google, Facebook, Apple), **SAML/OIDC** IdPs, Lambda triggers, adaptive authentication.
- **Identity pools (federated identities)**: exchange a token from a user pool, social, SAML or OIDC IdP for **temporary AWS credentials** (through STS) so the app can call AWS services directly. Supports **unauthenticated (guest)** access with a limited role.
- Common pattern: **user pool authenticates → identity pool authorizes AWS access**.
- User pools can act as an **authorizer for API Gateway**.

## When the exam wants it
- "Add sign-up/sign-in to a mobile/web app", "social login", "app users need access to S3/DynamoDB" → **Cognito** (user pool vs identity pool).

## Don't confuse with
- **IAM Identity Center** (workforce) and **IAM users** (internal staff).

## From the Domain 1 course
"Know Cognito **user pools**, **identity pools**, and how Cognito **brokers the SSO or ID federation**." Expect scenario questions on use cases.
