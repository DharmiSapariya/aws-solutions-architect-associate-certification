# AWS Service Index (every service in the SAA-C03 Exam Guide appendix)

Status: ✅ = notes file written (Domain 1 services, Day 2) | ⬜ = coming with its domain's day.
Source: Exam Guide v1.0 appendix. The list is non-exhaustive, and order is not a sign of weight.

## Notes already written (Domain 1)

### Identity and access
- ✅ [IAM](identity-and-access/iam.md) | [IAM Identity Center (AWS SSO)](identity-and-access/iam-identity-center.md) | [STS](identity-and-access/sts.md) | [Directory Service](identity-and-access/directory-service.md)
- ✅ [Organizations and SCPs](identity-and-access/organizations-and-scps.md) | [Control Tower](identity-and-access/control-tower.md) | [Cognito](identity-and-access/cognito.md) | [RAM](identity-and-access/resource-access-manager.md) | [Service Catalog](identity-and-access/service-catalog.md)

### Security services
- ✅ [GuardDuty](security-services/guardduty.md) | [Macie](security-services/macie.md) | [Shield](security-services/shield.md) | [WAF](security-services/waf.md) | [Firewall Manager](security-services/firewall-manager.md) | [Network Firewall](security-services/network-firewall.md)
- ✅ [Secrets Manager](security-services/secrets-manager.md) | [Systems Manager / Parameter Store](security-services/systems-manager-parameter-store.md) | [Inspector](security-services/inspector.md) | [Detective](security-services/detective.md) | [Security Hub](security-services/security-hub.md)
- ✅ [Artifact](security-services/artifact.md) | [Audit Manager](security-services/audit-manager.md) | [KMS](security-services/kms.md) | [CloudHSM](security-services/cloudhsm.md) | [ACM](security-services/certificate-manager.md)

### Monitoring and audit
- ✅ [CloudTrail](monitoring-and-audit/cloudtrail.md) | [CloudWatch](monitoring-and-audit/cloudwatch.md) | [Config](monitoring-and-audit/config.md) | [VPC Flow Logs](monitoring-and-audit/vpc-flow-logs.md)

### Networking
- ✅ [VPC](networking/vpc.md) | [Security groups](networking/security-groups.md) | [Network ACLs](networking/network-acls.md) | [NAT gateway](networking/nat-gateway.md) | [Endpoints and PrivateLink](networking/vpc-endpoints-and-privatelink.md)
- ✅ [VPC peering](networking/vpc-peering.md) | [Transit Gateway](networking/transit-gateway.md) | [Site-to-Site VPN](networking/site-to-site-vpn.md) | [Client VPN](networking/client-vpn.md) | [Direct Connect](networking/direct-connect.md)

### Storage and backup
- ✅ [S3 security and encryption](storage-and-backup/s3-security-and-encryption.md) | [S3 lifecycle and replication](storage-and-backup/s3-lifecycle-and-replication.md) | [EBS](storage-and-backup/ebs.md) | [EFS](storage-and-backup/efs.md) | [FSx](storage-and-backup/fsx.md)
- ✅ [AWS Backup](storage-and-backup/aws-backup.md) | [Storage Gateway](storage-and-backup/storage-gateway.md) | [Database backup and recovery](storage-and-backup/database-backup-and-recovery.md)

## Full in-scope list from the exam guide (tick off as notes are written)

**Analytics:** ⬜ Athena · ⬜ Data Exchange · ⬜ Data Pipeline · ⬜ EMR · ⬜ Glue · ⬜ Kinesis · ⬜ Lake Formation · ⬜ MSK · ⬜ OpenSearch Service · ⬜ QuickSight · ⬜ Redshift
**Application integration:** ⬜ AppFlow · ⬜ AppSync · ⬜ EventBridge · ⬜ Amazon MQ · ⬜ SNS · ⬜ SQS · ⬜ Step Functions
**Cost management:** ⬜ Budgets · ⬜ Cost and Usage Report · ⬜ Cost Explorer · ⬜ Savings Plans
**Compute:** ⬜ Batch · ⬜ EC2 · ⬜ EC2 Auto Scaling · ⬜ Elastic Beanstalk · ⬜ Outposts · ⬜ Serverless Application Repository · ⬜ VMware Cloud on AWS · ⬜ Wavelength
**Containers:** ⬜ ECR · ⬜ ECS · ⬜ ECS Anywhere · ⬜ EKS · ⬜ EKS Anywhere · ⬜ EKS Distro
**Database:** ⬜ Aurora · ⬜ Aurora Serverless · ⬜ DocumentDB · ⬜ DynamoDB · ⬜ ElastiCache · ⬜ Keyspaces · ⬜ Neptune · ⬜ QLDB · ⬜ RDS · ⬜ Redshift · ⬜ Timestream *(backups covered in Domain 1 database note)*
**Developer tools:** ⬜ X-Ray
**Front-end web and mobile:** ⬜ Amplify · ⬜ API Gateway · ⬜ Device Farm · ⬜ Pinpoint
**Machine learning:** ⬜ Comprehend · ⬜ Forecast · ⬜ Fraud Detector · ⬜ Kendra · ⬜ Lex · ⬜ Polly · ⬜ Rekognition · ⬜ SageMaker · ⬜ Textract · ⬜ Transcribe · ⬜ Translate
**Management and governance:** ⬜ Auto Scaling · ⬜ CloudFormation · ✅ CloudTrail · ✅ CloudWatch · ⬜ CLI · ⬜ Compute Optimizer · ✅ Config · ✅ Control Tower · ⬜ License Manager · ⬜ Managed Grafana · ⬜ Managed Service for Prometheus · ⬜ Management Console · ✅ Organizations · ⬜ Personal Health Dashboard · ⬜ Proton · ✅ Service Catalog · ✅ Systems Manager · ⬜ Trusted Advisor · ⬜ Well-Architected Tool
**Media services:** ⬜ Elastic Transcoder · ⬜ Kinesis Video Streams
**Migration and transfer:** ⬜ Application Discovery Service · ⬜ Application Migration Service · ⬜ DMS · ⬜ DataSync · ⬜ Migration Hub · ⬜ Server Migration Service · ⬜ Snow Family · ⬜ Transfer Family
**Networking and content delivery:** ⬜ CloudFront · ✅ Direct Connect · ⬜ Elastic Load Balancing · ⬜ Global Accelerator · ✅ PrivateLink · ⬜ Route 53 · ✅ Transit Gateway · ✅ VPC · ✅ VPN
**Security, identity, compliance:** ✅ Artifact · ✅ Audit Manager · ✅ ACM · ✅ CloudHSM · ✅ Cognito · ✅ Detective · ✅ Directory Service · ✅ Firewall Manager · ✅ GuardDuty · ✅ IAM · ✅ Inspector · ✅ KMS · ✅ Macie · ✅ Network Firewall · ✅ RAM · ✅ Secrets Manager · ✅ Security Hub · ✅ Shield · ✅ Single Sign-On (IAM Identity Center) · ✅ WAF
**Serverless:** ⬜ AppSync · ⬜ Fargate · ⬜ Lambda
**Storage:** ✅ Backup · ✅ EBS · ✅ EFS · ✅ FSx · ✅ S3 · ⬜ S3 Glacier (storage classes) · ✅ Storage Gateway

## Out of scope (do not study for the exam)
- **Analytics:** CloudSearch · **App integration:** MWAA · **AR/VR:** Sumerian · **Blockchain:** Managed Blockchain · **Compute:** Lightsail · **Database:** RDS on VMware
- **Developer tools:** Cloud9, CDK, CloudShell, CodeArtifact, CodeBuild, CodeCommit, CodeDeploy, CodeGuru, CodeStar, Corretto, Fault Injection Simulator, Tools and SDKs
- **Front-end:** Location Service · **Game tech:** GameLift, Lumberyard · **IoT:** all services
- **Machine learning:** MXNet on AWS, Augmented AI (A2I), DeepComposer, Deep Learning AMIs, Deep Learning Containers, DeepLens, DeepRacer, DevOps Guru, Elastic Inference, HealthLake, Inferentia, Lookout (Equipment/Metrics/Vision), Monitron, Panorama, Personalize, PyTorch on AWS, SageMaker Data Wrangler, SageMaker Ground Truth, TensorFlow on AWS
- **Management and governance:** Chatbot, Console Mobile Application, Distro for OpenTelemetry, OpsWorks
- **Media:** Elemental Appliances/Software, MediaConnect, MediaConvert, MediaLive, MediaPackage, MediaStore, MediaTailor, Interactive Video Service
- **Migration:** Migration Evaluator · **Networking:** App Mesh, Cloud Map · **Quantum:** Braket · **Robotics:** RoboMaker · **Satellite:** Ground Station
