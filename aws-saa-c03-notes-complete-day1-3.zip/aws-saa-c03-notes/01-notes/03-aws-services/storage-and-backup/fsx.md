# Amazon FSx
*Category: Storage | Scope: Regional (Single-AZ/Multi-AZ options) | Domain 1 (Task 1.3)*

## What it is
Managed third-party file systems: **FSx for Windows File Server** (SMB, Active Directory integration), **FSx for Lustre** (high-performance computing, S3 integration), **FSx for NetApp ONTAP**, **FSx for OpenZFS**.

## Security and protection
- **Encryption at rest** (KMS) and **in transit** (for example SMB encryption); **AD** integration for access control on Windows.
- **Automatic daily backups** and manual backups; supported by **AWS Backup**; Multi-AZ deployment for availability.

## When the exam wants it
- "Windows file shares/SMB with AD" → **FSx for Windows**. "HPC/ML scratch storage fast" → **FSx for Lustre**.

## From the Domain 1 course
AWS Backup supports **FSx for Windows File Server and FSx for Lustre**.
