# AWS Backup
*Category: Storage | Scope: Regional (with cross-Region and cross-account copy) | Domain 1 (Task 1.3)*

## What it is
A **centralized place to configure, schedule and monitor backups** across AWS services.

## Key features and how it works
- **Backup plans**: rules for schedule/frequency, backup window, **lifecycle** (move to cold storage, expire), resource assignment by **tags or ARNs**.
- **Backup vaults** (KMS encrypted), **Vault Lock** for **WORM** protection.
- **Cross-Region copy** (to a DR Region) and **cross-account copy**; org-wide **backup policies** through Organizations.
- Supported resources the course lists: **EBS volumes, EC2 instances, RDS and Aurora databases, DynamoDB tables, EFS file systems, Storage Gateway volumes, FSx for Windows File Server and FSx for Lustre** (plus others such as S3, DocumentDB, Neptune).
- Monitoring, compliance reports, restore testing.

## When the exam wants it
- "Centralize and automate backups of many services", "meet retention/compliance for backups", "copy backups to another Region".

## Don't confuse with
- Per-service snapshots (EBS, RDS) that AWS Backup orchestrates.

## From the Domain 1 course
**Backup frequency determines achievable recovery point (RPO)**; AWS Backup supports cross-Region copy to a DR Region.
