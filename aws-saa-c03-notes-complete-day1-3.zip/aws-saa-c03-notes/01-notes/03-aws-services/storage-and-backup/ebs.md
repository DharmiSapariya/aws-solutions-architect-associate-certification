# Amazon EBS (Elastic Block Store)
*Category: Storage | Scope: **AZ-scoped** volumes; snapshots regional | Domain 1 (Task 1.3)*

## What it is
Block storage volumes for EC2.

## Encryption and protection
- **Encryption with KMS** (AES-256) protects: **data at rest**, **data moving between the instance and the volume**, **snapshots**, and **volumes created from those snapshots**. **Minimal performance impact**.
- Can enable **encryption by default per Region**. You can't directly un-encrypt a volume.
- To encrypt an existing unencrypted volume: **snapshot → copy snapshot with encryption → create volume**.
- **Snapshots**: **incremental**, stored durably (S3-backed, managed by AWS); share with accounts (encrypted snapshots require sharing the customer managed key too); **copy across Regions** for DR; **Data Lifecycle Manager** and **AWS Backup** automate; **Fast Snapshot Restore**.
- Volume types (SSD gp3/io2, HDD st1/sc1) matter for performance/cost, covered in Domain 3-4.

## When the exam wants it
- "Data generated on an EC2 instance must be protected and durable, least effort" → **encrypted EBS volume** (course scenario).

## Don't confuse with
- **EFS** (shared NFS file system), **S3** (object), **instance store** (ephemeral).

## From the Domain 1 course
EBS snapshot is listed under backup services; the EBS-vs-S3 encrypted storage scenario: **encrypted EBS volume is the least effort**.
