# Amazon EFS (Elastic File System)
*Category: Storage | Scope: Regional (Multi-AZ) | Domain 1 (Task 1.3), Domain 2-4*

## What it is
Managed, elastic **NFS file system** for **Linux** workloads, shared by many instances/containers/Lambda.

## Security and protection
- **Encryption at rest** with KMS (**enable at creation**) and **encryption in transit** with TLS (EFS mount helper).
- Access control: **security groups**, **IAM authorization**, **file system policies**, **EFS access points**, POSIX permissions.
- **Backups** with **AWS Backup** (automatic backups on by default) and **replication** to another Region/AZ.
- Storage classes: Standard, Infrequent Access, Archive with lifecycle management.

## When the exam wants it
- Shared Linux file storage across AZs; protect with encryption and backups.

## Don't confuse with
- **EBS** (single instance/AZ), **FSx for Windows** (SMB), **S3**.

## From the Domain 1 course
"EFS backup when using AWS Backup" is listed in backup features.
