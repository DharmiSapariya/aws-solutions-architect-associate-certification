# Database Backup and Recovery (RDS, Aurora, DynamoDB, Redshift, Neptune, DocumentDB)
*Category: Database | Scope: Regional | Domain 1 (Task 1.3), Domain 2*

## RDS
- **Automated backups**: daily snapshot + transaction logs, **retention 1 to 35 days** (default 7), **point-in-time restore** to a new instance. **Manual snapshots** stay until deleted.
- **Multi-AZ is high availability, not a backup.** Restores create a **new DB instance**.
- **Encryption at rest** (KMS) must be enabled **at creation**; encrypt an existing DB by snapshot → copy encrypted → restore. Snapshots can be **copied cross-Region/shared cross-account**.

## Aurora
- **Continuous backup to S3**, **point-in-time restore**, **cluster snapshots**; **Backtrack** (MySQL-compatible) rewinds in place; **Aurora Global Database** for cross-Region DR.

## DynamoDB
- **Point-in-time recovery (PITR)** (restore to any second in the last **35 days**), **on-demand backups**, **AWS Backup** support, **Global Tables** for multi-Region replication.

## Redshift
- **Automated snapshots** (about every 8 hours or per 5 GB of changes per node, default 1-day retention), **manual snapshots**, **cross-Region snapshot copy**.

## Neptune and DocumentDB
- **Continuous backup** with retention up to **35 days** and **cluster snapshots**; restore to a new cluster.

## When the exam wants it
- "Restore to a point in time", "DR for a database across Regions", "backup retention".

## From the Domain 1 course
Listed services to dive into: **RDS snapshot, Aurora snapshot, DynamoDB backup, Redshift snapshot, Neptune snapshot, DocumentDB**. Exam guide skill: implement data backups and replications.
