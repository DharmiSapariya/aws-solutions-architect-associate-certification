# Amazon S3: Lifecycle, Intelligent-Tiering and Replication
*Category: Storage | Scope: Regional bucket | Domain 1 (Task 1.3), Domain 4*

## Lifecycle configurations
- **Transition** objects between classes (Standard → Standard-IA/One Zone-IA → Glacier Instant/Flexible → Glacier Deep Archive) after set days; **expire** objects; manage **noncurrent versions**; **abort incomplete multipart uploads**.
- Best for **known, predictable** access patterns. Minimum storage duration and (for IA classes) minimum object size charges apply.

## S3 Intelligent-Tiering
- Automatically moves objects between access tiers based on **changing or unknown access patterns**.
- **Monitoring and automation fee** per object, **no retrieval fees**; small objects (<128 KB) aren't monitored.
- Course question: *when use lifecycle configurations instead of Intelligent-Tiering?* → when patterns are **known/predictable**; use Intelligent-Tiering when they're **unknown/changing**.

## Replication (CRR and SRR)
- **Cross-Region Replication (CRR)** and **Same-Region Replication (SRR)**; **asynchronous**, continuous.
- **Versioning must be enabled on source and destination buckets**; requires an **IAM role**; works across accounts; can change storage class/ownership; KMS-encrypted objects supported with configuration.
- Only **new objects** replicate by default (use **S3 Batch Replication** for existing); replication is **not chained**; **S3 Replication Time Control** offers a 15-minute SLA.
- DR use: CRR copies objects to the DR Region with versioning so you can **choose the restore point**.

## When the exam wants it
- "Copy data to another Region for DR/compliance/latency" → CRR. "Reduce cost over time" → lifecycle/Intelligent-Tiering.

## From the Domain 1 course
"For Amazon S3, use **Cross-Region Replication** to asynchronously copy objects to a bucket in the DR Region continuously while providing versioning." Policies for data access, lifecycle and protection are an exam guide skill.
