# Amazon S3: Security and Encryption
*Category: Storage | Scope: Regional bucket, global namespace | Domain 1 (Task 1.3)*

## What it is
Object storage with very high durability (11 nines). For Domain 1 the focus is how to **secure and encrypt** it.

## Access control
- **IAM policies** (identity), **bucket policies** (resource-based, with `Principal`), **S3 Block Public Access** (account and bucket level), **access points**, **pre-signed URLs**, **VPC endpoint policies**.
- **ACLs** are legacy; **Object Ownership "bucket owner enforced"** disables them.
- Control granularity: **whole bucket, prefix (path), or object**.
- **IAM Access Analyzer for S3**, **Macie** (find sensitive data), **CloudTrail data events** (audit object access).

## Encryption in transit
HTTPS/TLS; enforce with a bucket policy condition **`aws:SecureTransport`**.

## Encryption at rest
| Option | Who holds keys | Notes |
|---|---|---|
| **SSE-S3** | S3-managed keys (AES-256) | Simplest; **default for new objects** since 2023 |
| **SSE-KMS** | **KMS keys** (course: "customer master keys stored in KMS") | Key policy control, **CloudTrail audit**, **S3 Bucket Keys** cut KMS calls/cost; KMS request quotas can throttle |
| **SSE-C** | **Customer-provided keys**, sent with each request | AWS doesn't store the key; must use HTTPS |
| **DSSE-KMS** | Dual-layer server-side with KMS | Compliance use |
| **Client-side** | You encrypt **before upload** | You control everything |
- With **server-side** encryption S3 uses default HTTPS in transit then encrypts on arrival; with **client-side** you handle all of it.

## Data protection features
**Versioning**, **MFA Delete**, **Object Lock** (WORM; governance vs compliance mode; legal hold), **Glacier Vault Lock**, **Replication** and **lifecycle** (see lifecycle note).

## When the exam wants it
- "Encrypt S3 data with customer control and audit" → SSE-KMS. "Customer supplies keys" → SSE-C. "Prevent public exposure" → Block Public Access. "WORM retention for compliance" → Object Lock.

## From the Domain 1 course
Know client-side vs server-side encryption and the three server-side choices (customer-provided keys, S3-managed keys, KMS keys); S3 allows security for entire buckets plus specific paths or objects.
