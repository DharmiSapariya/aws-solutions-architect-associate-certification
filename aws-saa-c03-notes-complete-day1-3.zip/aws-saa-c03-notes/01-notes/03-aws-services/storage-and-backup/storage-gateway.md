# AWS Storage Gateway
*Category: Storage (hybrid) | Scope: on-prem appliance connected to Regional AWS storage | Domain 1 (Task 1.3), Domain 3-4*

## What it is
A **hybrid cloud storage** service giving on-prem applications access to AWS storage with local caching.

## Gateway types
| Type | Protocol | Backed by |
|---|---|---|
| **S3 File Gateway** | NFS/SMB | S3 (objects) |
| **FSx File Gateway** | SMB | FSx for Windows File Server |
| **Volume Gateway** | iSCSI (cached or stored volumes) | S3 with **EBS snapshots** |
| **Tape Gateway** | iSCSI VTL | S3 / Glacier archive |
- Runs as a VM or hardware appliance on-prem; data **encrypted in transit (TLS)** and **at rest** in AWS (SSE, KMS options).

## When the exam wants it
- "Hybrid environment", "on-prem backup/archival to AWS without changing applications", "low-latency access to frequently used cloud data".

## Don't confuse with
- **DataSync** (bulk data transfer/migration), **Snow family**, **Transfer Family**.

## From the Domain 1 course
"What service can we use for hybrid environments? **AWS Storage Gateway**."
