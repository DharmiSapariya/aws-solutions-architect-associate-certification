# Daily Study Log

## 2026-10-15 — Day 1
- ✅ Exam Prep Plan Overview (15m)
- ✅ Exam Prep Overview (20m)
- 🔄 Official Practice Question Set (in progress)
- 📝 Notes added: exam prep plan, exam prep overview, exam guide summary
- 🎯 Next: finish the practice set, log mistakes, start Domain 1 Review

## 2026-10-15 — Day 2 (edit the date if needed)
- ✅ Domain 1 Review: Design Secure Architectures (45m)
- 📝 Notes added: in-depth Domain 1 notes (3 task statements, wrap-up, cheat sheet, 51-question self-quiz), 47 per-service notes, service index of every exam-guide service, full exam guide checklist
- 🎯 Next: Domain 1 Practice (30m), then Domain 1 SimuLearn lab; add the 3 walkthrough questions to the practice-questions folder

## 2026-10-15 — Day 3 (edit the date if needed)
- ✅ Domain 1 Practice: assessment 5/5 (100%, 3m29s), 3 walkthrough questions, 14 flashcards
- 📝 Notes added: practice assessment breakdown, walkthrough method and breakdown, flashcards with clarifications, Domain 1 takeaways and traps, mistakes log traps, KMS note update
- 🎯 Next: Domain 1 SimuLearn lab (build the three-tier secure design), finish the 20-question Official Practice Question Set, then Domain 2 Review

<!-- Copy this block each day:
## YYYY-MM-DD — Day N
- ✅ Done:
- 🔄 In progress:
- 📝 Notes added:
- 🎯 Next:
-->
